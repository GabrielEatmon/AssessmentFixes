Install the site locally. A backup of the database is located at wp-content/wptest-backup.sql.

Credentials for the site are:

username: tester

password: 1mT35t1nH3r3!

Create and assign a main menu that matches the menu items from the previous projects. The menu should look and function the same as the first assessment.

Change the post excerpt length to 40 words.

Change the read more text to ellipsis and a read more link with text "Read More!"

Change the thumbnail size of the posts on the front page to use a 900px wide image that scales to the full width of the containing element and scales uniformly.

Save the database dump to wp-content/wptest-submission.sql. Zip up the whole site directory and upload it to the FTP folder you used for the previous assessment.